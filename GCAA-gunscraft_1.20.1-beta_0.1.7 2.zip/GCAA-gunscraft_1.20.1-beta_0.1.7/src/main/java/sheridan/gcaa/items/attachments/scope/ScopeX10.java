package sheridan.gcaa.items.attachments.scope;

import sheridan.gcaa.items.attachments.Scope;

public class ScopeX10 extends Scope {
    public ScopeX10() {
        super(10, 5, 0.75f, 2f);
    }
}
