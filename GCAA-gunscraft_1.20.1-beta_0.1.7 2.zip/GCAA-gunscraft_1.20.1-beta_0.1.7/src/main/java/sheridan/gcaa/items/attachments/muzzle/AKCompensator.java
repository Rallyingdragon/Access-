package sheridan.gcaa.items.attachments.muzzle;

import sheridan.gcaa.items.attachments.Compensator;

public class AKCompensator extends Compensator {
    public AKCompensator() {
        super(0.2f, 0.1f, 0.1f, 0.1f);
    }
}
