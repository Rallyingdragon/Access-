package sheridan.gcaa.items.ammunitions;

public class PistolRounds extends Ammunition{
    public PistolRounds() {
        super(2000);
    }
}
