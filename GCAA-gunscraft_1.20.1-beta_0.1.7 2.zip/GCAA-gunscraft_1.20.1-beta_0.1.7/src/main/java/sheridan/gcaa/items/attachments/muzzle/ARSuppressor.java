package sheridan.gcaa.items.attachments.muzzle;

import sheridan.gcaa.items.attachments.Suppressor;

public class ARSuppressor extends Suppressor {
    public ARSuppressor() {
        super(0.4f, 0.1f, 0.07f, 1f);
    }
}