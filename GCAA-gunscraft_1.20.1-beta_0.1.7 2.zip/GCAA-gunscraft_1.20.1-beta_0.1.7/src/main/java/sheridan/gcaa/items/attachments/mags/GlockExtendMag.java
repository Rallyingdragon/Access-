package sheridan.gcaa.items.attachments.mags;

import sheridan.gcaa.items.attachments.Mag;

public class GlockExtendMag extends Mag {
    public GlockExtendMag() {
        super(22, 0.5f);
    }
}
