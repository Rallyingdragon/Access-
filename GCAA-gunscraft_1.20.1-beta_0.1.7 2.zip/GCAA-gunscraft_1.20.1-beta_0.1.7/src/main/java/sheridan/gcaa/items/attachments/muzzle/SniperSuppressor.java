package sheridan.gcaa.items.attachments.muzzle;

import sheridan.gcaa.items.attachments.Suppressor;

public class SniperSuppressor extends Suppressor {
    public SniperSuppressor() {
        super(0.5f, 0.10f, 0.10f, 1.5f);
    }
}
