package sheridan.gcaa.items.attachments.mags;

import sheridan.gcaa.items.attachments.Mag;

public class ShotgunExtendBay extends Mag {
    public ShotgunExtendBay() {
        super(8, 0.8f);
    }
}
