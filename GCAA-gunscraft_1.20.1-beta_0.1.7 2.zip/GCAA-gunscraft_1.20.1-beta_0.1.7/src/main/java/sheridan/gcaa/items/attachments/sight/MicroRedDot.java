package sheridan.gcaa.items.attachments.sight;

import sheridan.gcaa.items.attachments.Sight;

public class MicroRedDot extends Sight {
    public MicroRedDot() {
        super(0.25f);
    }
}
