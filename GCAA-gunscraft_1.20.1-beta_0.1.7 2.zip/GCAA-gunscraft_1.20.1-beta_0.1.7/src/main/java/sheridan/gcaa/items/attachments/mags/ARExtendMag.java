package sheridan.gcaa.items.attachments.mags;

import sheridan.gcaa.items.attachments.Mag;

public class ARExtendMag extends Mag {
    public ARExtendMag() {
        super(40, 1.3f);
    }
}
