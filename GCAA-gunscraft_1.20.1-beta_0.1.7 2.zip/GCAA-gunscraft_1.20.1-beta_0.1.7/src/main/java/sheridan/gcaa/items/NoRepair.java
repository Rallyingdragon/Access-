package sheridan.gcaa.items;

public interface NoRepair {
}
