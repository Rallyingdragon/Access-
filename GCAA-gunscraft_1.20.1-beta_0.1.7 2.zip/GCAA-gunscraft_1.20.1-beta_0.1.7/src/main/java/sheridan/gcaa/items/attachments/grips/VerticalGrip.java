package sheridan.gcaa.items.attachments.grips;

import sheridan.gcaa.items.attachments.Grip;

public class VerticalGrip extends Grip {
    public VerticalGrip() {
        super(0.12f, 0.07f, 0.08f, 0.5f);
    }
}
