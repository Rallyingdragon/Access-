package sheridan.gcaa.items.attachments.muzzle;

import sheridan.gcaa.items.attachments.Suppressor;

public class AKSuppressor extends Suppressor {
    public AKSuppressor() {
        super(0.4f, 0.1f, 0.07f, 1f);
    }
}
