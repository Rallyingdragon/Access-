package sheridan.gcaa.items.attachments.mags;

import sheridan.gcaa.items.attachments.Mag;

public class AKExtendMag extends Mag {
    public AKExtendMag() {
        super(40, 1.6f);
    }
}
