package sheridan.gcaa.items.attachments.muzzle;

import sheridan.gcaa.items.attachments.Compensator;

public class SMGCompensator extends Compensator {
    public SMGCompensator() {
        super(0.15f, 0.15f, 0.15f, 0.15f);
    }
}
