package sheridan.gcaa.items.attachments.muzzle;

import sheridan.gcaa.items.attachments.Suppressor;

public class OspreySuppressor extends Suppressor {
    public OspreySuppressor() {
        super(0.45f, 0.08f, 0.08f, 0.75f);
    }
}
