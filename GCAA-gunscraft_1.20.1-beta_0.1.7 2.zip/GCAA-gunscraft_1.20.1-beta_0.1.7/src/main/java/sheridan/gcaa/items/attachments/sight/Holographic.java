package sheridan.gcaa.items.attachments.sight;

import sheridan.gcaa.items.attachments.Sight;

public class Holographic extends Sight {
    public Holographic() {
        super( 0.8f);
    }
}
