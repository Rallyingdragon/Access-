package sheridan.gcaa.items.attachments.muzzle;

import sheridan.gcaa.items.attachments.Compensator;

public class ARCompensator extends Compensator {
    public ARCompensator() {
        super(0.16f, 0.16f, 0.12f, 0.12f);
    }
}