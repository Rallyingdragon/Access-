package sheridan.gcaa.items.attachments.sight;

import sheridan.gcaa.items.attachments.Sight;

public class RedDot extends Sight {
    public RedDot() {
        super(0.5f);
    }
}
