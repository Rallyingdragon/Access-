package sheridan.gcaa.items.attachments.scope;

import sheridan.gcaa.items.attachments.Scope;

public class Acog extends Scope {

    public Acog() {
        super( 4, 1.5f, 0.9f, 1.5f);
    }
}
