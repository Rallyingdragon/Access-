package sheridan.gcaa.items.attachments.mags;

import sheridan.gcaa.items.attachments.Mag;

public class Vector45ExtendMag extends Mag {
    public Vector45ExtendMag() {
        super(25, 0.8f);
    }
}
