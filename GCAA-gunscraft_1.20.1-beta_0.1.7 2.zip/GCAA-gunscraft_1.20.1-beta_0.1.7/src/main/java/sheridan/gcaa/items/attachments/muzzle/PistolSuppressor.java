package sheridan.gcaa.items.attachments.muzzle;

import sheridan.gcaa.items.attachments.Suppressor;

public class PistolSuppressor extends Suppressor {
    public PistolSuppressor() {
        super(0.4f, 0.05f, 0.05f, 0.5f);
    }
}
