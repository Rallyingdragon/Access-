package sheridan.gcaa.blocks;

import net.minecraft.world.level.block.Block;

public class AmmunitionProcessor extends Block {

    public AmmunitionProcessor(Properties pProperties) {
        super(pProperties);
    }
}
