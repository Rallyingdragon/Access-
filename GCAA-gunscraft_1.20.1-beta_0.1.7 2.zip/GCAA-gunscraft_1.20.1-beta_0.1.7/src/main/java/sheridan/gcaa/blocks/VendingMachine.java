package sheridan.gcaa.blocks;

import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraftforge.common.extensions.IForgeBlock;

public class VendingMachine extends HorizontalDirectionalBlock implements IForgeBlock {
    protected VendingMachine(Properties pProperties) {
        super(pProperties);
    }
}
