package sheridan.gcaa.attachmentSys;

public interface IAttachmentSlotProxyCreator {
    AttachmentSlotProxy create(AttachmentSlot slot);
}
